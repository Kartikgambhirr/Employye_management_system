from rest_framework import serializers

from ems_web.models.Grievance import Grievance


class GrievanceSerializer(serializers.ModelSerializer):

	class Meta:
		model = Grievance
		fields = '__all__'