from django.db import models

from ems_web.models.Employee import Employee


class Leave(models.Model):
    response_choice =(
        ("pending", "Pending"),
        ("denied", "Denied"),
        ("approved", "Approved")
    )

    reason = models.TextField()
    start_date = models.DateField(auto_now_add=True)
    end_date = models.DateField()
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True, blank=True)
    type = models.CharField(max_length=255)
    response = models.CharField(max_length=60, default="pending",choices = response_choice,blank=True)

    dateCreated = models.DateTimeField(auto_now_add=True)
    dateUpdated = models.DateTimeField(auto_now=True)


