from django.contrib import admin

from ems_web.models.Employee import Employee
from ems_web.models.Grievance import Grievance
from ems_web.models.Leave import Leave
from ems_web.models.Salary import Salary
from ems_web.models.Schedule import Schedule

admin.site.register(Employee)

@admin.register(Schedule)
class Schedule(admin.ModelAdmin):
    pass
@admin.register(Leave)
class Leave(admin.ModelAdmin):
    pass

@admin.register(Grievance)
class Grievance(admin.ModelAdmin):
    pass

@admin.register(Salary)
class Salary(admin.ModelAdmin):
    pass
# Register your models here.
