from rest_framework import permissions
from ems_web.models.Employee import Employee


class IsUserAdmin(permissions.BasePermission):

	def has_permission(self, request, view):

		is_admin = False

		user = Employee.objects.get(username=request.user.username)

		print(user)
		
		if user.is_admin:
			is_admin = True
		
		return is_admin