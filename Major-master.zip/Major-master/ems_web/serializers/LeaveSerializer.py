from rest_framework import serializers
from ems_web.models.Leave import Leave


class LeaveSerializer(serializers.ModelSerializer):

	class Meta:
		model = Leave
		fields = '__all__'