from django.shortcuts import render, redirect

from django.contrib.auth.decorators import login_required

from django.http import HttpResponse


from ems_web.models.Leave import Leave
from ems_web.serializers.LeaveSerializer import LeaveSerializer

@login_required
def leavelist(request):
    try:
        leave = Leave.objects.filter(employee=request.user.employee)
        print(leave)
        return render(request, template_name='leave_list.html', context={'leave': leave})
    except Exception as err:
        print(str(err))
        return HttpResponse("no information found")

@login_required
def createleave(request):
    data = request.POST.copy()
    print(data)
    ser = LeaveSerializer(data=data)
    if ser.is_valid():
        instance = ser.save()
        instance.employee = request.user.employee
        instance.save()
        return redirect("/leave_land/")
    else:
        return HttpResponse(str(ser.errors))
