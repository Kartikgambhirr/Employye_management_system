
from django.urls import path

from ems_web.views.EmployeeView import welcome, loginview
from ems_web.views.GrievanceView import creategrievance, grievancelist
from ems_web.views.LeaveView import createleave, leavelist
from ems_web.views.SalaryView import salary
from ems_web.views.ScheduleView import schedule, confirmschedule
from ems_web.views.views import home, index, emp_admin, admin_land, delete, leave_land, grievance_land, \
    logoutview, leave, about, contact, grievance, create_user



urlpatterns = [

    path('create/', create_user, name='create_user'),
    path('', home, name='home'),
    path('index/', index, name='index'),
    path('emp_admin/', emp_admin, name='emp_admin'),
    path('contact/', contact, name='contact'),
    path('about/', about, name='about'),
    path('grievance/', grievance, name='grievance'),
    path('leave/', leave, name='leave'),
    path('welcome/', welcome, name='welcome'),
    path('salary/', salary, name='salary'),

    path('schedule/', schedule, name='schedule'),
    path('confirmschedule/', confirmschedule, name='confirmschedule'),

    path('creategrievance/', creategrievance, name='creategrievance'),
    path('grievancelist/', grievancelist, name='grievancelist'),

    path('createleave/', createleave, name='createleave'),
    path('leavelist/', leavelist, name='leavelist'),

    path('grievance_land/', grievance_land, name='grievance_land'),
    path('leave_land/', leave_land, name='leave_land'),
    path('delete/', delete, name='delete'),
    path('admin_land/', admin_land, name='admin_land'),

    path('login/', loginview, name='loginview'),
    path('logout/', logoutview, name='logoutview'),
]
