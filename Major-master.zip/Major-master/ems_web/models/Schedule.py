from cloudinary.models import CloudinaryField
from django.db import models

from ems_web.models.Employee import Employee



class Schedule(models.Model):

    responselist = (
        ('yes', 'yes'),
        ("no", "no")
    )
    tt = CloudinaryField('image', null=True, blank=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True, blank=True)
    response = models.CharField(max_length=255, choices=responselist, null=True, blank=True)
    task = models.CharField(max_length=255,null=True,blank=True)
    dateCreated = models.DateTimeField(auto_now_add=True)
    dateUpdated = models.DateTimeField(auto_now=True)




# Create your models here.
