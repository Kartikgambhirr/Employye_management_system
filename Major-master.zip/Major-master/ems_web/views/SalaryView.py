from django.shortcuts import render, redirect
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view
from django.contrib.auth.hashers import make_password

from ems_web.common.permissions import IsUserAdmin
from ems_web.models.Salary import Salary
from ems_web.models.Schedule import Schedule
from ems_web.serializers.EmployeeSerializer import EmployeeSerializer
from ems_web.serializers.GrievanceSerializer import GrievanceSerializer
from ems_web.serializers.LeaveSerializer import LeaveSerializer
from ems_web.serializers.SalarySerializer import SalarySerializer
from ems_web.models.Employee import Employee

@login_required
def salary(request):
    try :
        sal = Salary.objects.get(employee=request.user.employee)
        return render(request, template_name='salary.html', context={'sal': sal})
    except :
        return HttpResponse("No salary detail found")