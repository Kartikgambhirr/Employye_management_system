from django.db import models

from ems_web.models.Employee import Employee


class Grievance(models.Model):

    dep_name = models.CharField(max_length=50)
    complaint = models.TextField(max_length=500)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True, blank=True)
    response = models.TextField(null=True, blank=True)

    dateCreated = models.DateTimeField(auto_now_add=True)
    dateUpdated = models.DateTimeField(auto_now=True)


