from django.shortcuts import render, redirect
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view
from django.contrib.auth.hashers import make_password

from ems_web.common.permissions import IsUserAdmin
from ems_web.models.Salary import Salary
from ems_web.models.Schedule import Schedule
from ems_web.serializers.EmployeeSerializer import EmployeeSerializer
from ems_web.serializers.GrievanceSerializer import GrievanceSerializer
from ems_web.serializers.LeaveSerializer import LeaveSerializer
from ems_web.serializers.SalarySerializer import SalarySerializer
from ems_web.models.Employee import Employee

def home(request):
    return render(request, template_name='home.html')


def about(request):
    return render(request, template_name='about.html')


def contact(request):
    return render(request, template_name='contact.html')


@login_required
def leave(request):
    return render(request, template_name='leave.html')


@login_required
def grievance(request):
    return render(request, template_name='grievance.html')


@login_required
def leave_land(request):
    return render(request, template_name='leave_land.html')


@login_required
def grievance_land(request):
    return render(request, template_name='grievance_land.html')

@login_required
def admin_land(request):
    return render(request, template_name='admin_land.html')


@login_required
def logoutview(request):
    auth_logout(request)
    return redirect('/')


def index(request):
    if request.user.is_anonymous is False: 
        if request.user.is_authenticated:
            return redirect('/welcome')
    return render(request, template_name='index.html' )



@login_required
@api_view(('GET',))
@permission_classes((IsUserAdmin, ))
def emp_admin(request):
    adm = Employee.objects.filter(is_admin=True)
    if adm is not None:
        return render(request, template_name='admin.html', context={'adm': adm})
    else:
        return HttpResponse("you are not allowed to view this page")









@login_required
def create_user(request):
    is_admin = request.POST.get('is_admin',None)
    print(is_admin)
    data = request.POST.copy()
    data['password'] = make_password(data['password'])
    ser = EmployeeSerializer(data=data)
    if ser.is_valid():
        instance = ser.save()
        instance.is_active = True
        if is_admin is True:
            instance.is_admin = True
        instance.save()
        return HttpResponse("employee created")
    else:
        return HttpResponse(str(ser.errors))








@login_required
def delete(request):
    username = request.POST['username']
    try:
        emp = Employee.objects.get(username=username)
        emp.delete()
        return HttpResponse("Employee deleted")
    except:
        return HttpResponse("Employee could not be deleted")




