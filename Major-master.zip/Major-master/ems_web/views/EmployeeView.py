from django.shortcuts import render, redirect
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view
from django.contrib.auth.hashers import make_password

from ems_web.common.permissions import IsUserAdmin
from ems_web.models.Salary import Salary
from ems_web.models.Schedule import Schedule
from ems_web.serializers.EmployeeSerializer import EmployeeSerializer
from ems_web.serializers.GrievanceSerializer import GrievanceSerializer
from ems_web.serializers.LeaveSerializer import LeaveSerializer
from ems_web.serializers.SalarySerializer import SalarySerializer
from ems_web.models.Employee import Employee


@login_required
def create_user(request):
    is_admin = request.POST.get('is_admin', None)
    print(is_admin)
    data = request.POST.copy()
    data['password'] = make_password(data['password'])
    ser = EmployeeSerializer(data=data)
    if ser.is_valid():
        instance = ser.save()
        instance.is_active = True
        if is_admin is True:
            instance.is_admin = True
        instance.save()
        return redirect("/admin_land/")
    else:
        return HttpResponse(str(ser.errors))



def loginview(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(username=username, password=password)
    if user is not None:
        login(request, user)
        return redirect('/welcome/')
    else:
        return HttpResponse("Login details incorrect")



@login_required
def welcome(request):

    try:
        emp = Employee.objects.get(username=request.user.username)
        return render(request, template_name='welcome.html', context={'emp': emp})
    except:
        return HttpResponse("Please login again")
