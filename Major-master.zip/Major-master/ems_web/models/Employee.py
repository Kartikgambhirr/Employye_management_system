from django.db import models
from django.contrib.auth.models import User


class Employee(User):
    #personal details
    phone_number = models.CharField(max_length=10)
    dob = models.DateField()
    eid = models.CharField(max_length=10, null=True, blank=True)
    is_admin = models.BooleanField(default=False)
    #academic details
    school = models.CharField(max_length=100, default="NA", null=True, blank=True)
    ug = models.CharField(max_length=100, default="NA", null=True, blank=True)
    pg = models.CharField(max_length=100,default="NA", null=True, blank=True)
    phd = models.CharField(max_length=100, default="NA", null=True, blank=True)

    #employee details
    doj = models.DateTimeField(auto_now=True, null=True,blank=True)
    department = models.CharField(max_length=100, null=True, blank=True)
    post = models.CharField(max_length=100, null=True, blank=True)
    status = models.CharField(max_length=100, null=True, blank=True)

    #salary details
    bs = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    ta = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    da = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    hra = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    it = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)

    pf = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    totalsalary = models.DecimalField(max_digits=10, decimal_places=3, default=0.0, blank=True)
    account = models.CharField(max_length=100, null=True, blank=True, default="NA")

    dateCreated = models.DateTimeField(auto_now_add=True)
    dateUpdated = models.DateTimeField(auto_now=True)


