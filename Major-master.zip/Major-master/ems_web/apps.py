from django.apps import AppConfig


class EmsWebConfig(AppConfig):
    name = 'ems_web'
