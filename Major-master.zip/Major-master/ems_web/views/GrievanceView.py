from django.shortcuts import render, redirect
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from rest_framework.decorators import permission_classes, api_view
from django.contrib.auth.hashers import make_password

from ems_web.common.permissions import IsUserAdmin
from ems_web.models.Grievance import Grievance
from ems_web.models.Salary import Salary
from ems_web.models.Schedule import Schedule
from ems_web.serializers.EmployeeSerializer import EmployeeSerializer
from ems_web.serializers.GrievanceSerializer import GrievanceSerializer
from ems_web.serializers.LeaveSerializer import LeaveSerializer
from ems_web.serializers.SalarySerializer import SalarySerializer
from ems_web.models.Employee import Employee


@login_required
def creategrievance(request):
    data = request.POST.copy()
    ser = GrievanceSerializer(data=data)
    if ser.is_valid():
        instance = ser.save()
        instance.employee=request.user.employee
        instance.save()
        return redirect("/grievance_land/")
    else:
        return HttpResponse(str(ser.errors))


@login_required
def grievancelist(request):

    try:
        grief = Grievance.objects.filter(employee=request.user.employee)
        print(grief)
        return render(request, template_name='greivance_list.html', context={'grief': grief})
    except Exception as err:
        print(str(err))
        return HttpResponse("no information found")


