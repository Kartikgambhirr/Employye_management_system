from rest_framework import serializers
from ems_web.models.Salary import Salary


class SalarySerializer(serializers.ModelSerializer):

	class Meta:
		model = Salary
		fields = '__all__'