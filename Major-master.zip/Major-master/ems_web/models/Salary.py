from django.db import models

from ems_web.models.Employee import Employee


class Salary(models.Model):

    monthlysalary = models.DecimalField(max_digits=10, decimal_places=3, default=0.0,null=True,blank=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=255, default="Pending",null=True,blank=True)

    issuedon = models.DateField(null=True,blank=True)



