from rest_framework import serializers

from ems_web.models.Schedule import Schedule


class ScheduleSerializer(serializers.ModelSerializer):

	class Meta:
		model = Schedule
		fields = '__all__'
